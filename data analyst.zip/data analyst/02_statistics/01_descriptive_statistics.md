# Descriptive Statistics: A Comprehensive Guide

## 1. Measures of Central Tendency

### 1.1 Mean (Arithmetic Average)

```ascii
Data: [2, 4, 4, 4, 5, 5, 7, 9]
Mean = (2 + 4 + 4 + 4 + 5 + 5 + 7 + 9) ÷ 8 = 5

     Mean
      ↓
2  4  5  7  9
   4  5
   4
```

#### Key Points:
- Definition: Sum of all values divided by number of values
- Advantages:
  * Takes all values into account
  * Suitable for further statistical calculations
- Disadvantages:
  * Sensitive to outliers
  * May not represent the "typical" value in skewed distributions

### 1.2 Median (Middle Value)

```ascii
Ordered Data: 2, 4, 4, 4, 5, 5, 7, 9
                    ↑  ↑
              Median = (4 + 5) ÷ 2 = 4.5

For odd number of values:
2, 4, 4, 5, 7
      ↑
   Median = 4
```

#### Key Points:
- Definition: Middle value when data is ordered
- Calculation:
  * Odd n: Middle position = (n+1)/2
  * Even n: Average of two middle positions
- Advantages:
  * Not affected by outliers
  * Better for skewed distributions
- Disadvantages:
  * Doesn't use all data points
  * Less suitable for mathematical operations

### 1.3 Mode (Most Frequent Value)

```ascii
Data: 2, 4, 4, 4, 5, 5, 7, 9

Frequency Distribution:
 Value | Frequency
-------|----------
   2   |    1
   4   |    3  ← Mode
   5   |    2
   7   |    1
   9   |    1
```

#### Key Points:
- Definition: Most frequently occurring value
- Types:
  * Unimodal: One mode
  * Bimodal: Two modes
  * Multimodal: Multiple modes
- Best for:
  * Categorical data
  * Discrete numerical data

## 2. Measures of Dispersion

### 2.1 Range

```ascii
Data: 2, 4, 4, 4, 5, 5, 7, 9
      ↑              ↑
    Min = 2       Max = 9

Range = Max - Min = 9 - 2 = 7

Visual Representation:
2 -------|-------|-------|-------|-------|-------|-----> 9
         3       4       5       6       7       8
```

#### Key Points:
- Definition: Difference between largest and smallest values
- Advantages:
  * Simple to calculate and understand
  * Gives quick overview of data spread
- Disadvantages:
  * Only uses two values
  * Highly sensitive to outliers

### 2.2 Variance

```ascii
Step 1: Calculate mean (μ)
Step 2: Calculate squared deviations
Step 3: Find average of squared deviations

Formula: σ² = Σ(x - μ)² ÷ n

Example:
Data: 2, 4, 4, 4, 5, 5, 7, 9
Mean (μ) = 5

Deviations Squared:
(2-5)² = 9
(4-5)² = 1 (three times)
(5-5)² = 0 (two times)
(7-5)² = 4
(9-5)² = 16

Variance = (9 + 1 + 1 + 1 + 0 + 0 + 4 + 16) ÷ 8 = 4
```

### 2.3 Standard Deviation

```ascii
Formula: σ = √(Variance)

In our example:
σ = √4 = 2

Empirical Rule (68-95-99.7):

                 68%
    |←---------------------------→|
         95%
|←---------------------------------→|
            99.7%
|←-------------------------------------→|

-3σ    -2σ    -1σ     μ     +1σ    +2σ    +3σ
```

#### Key Points:
- Definition: Square root of variance
- Interpretation:
  * Approximately 68% of data within ±1σ
  * Approximately 95% of data within ±2σ
  * Approximately 99.7% of data within ±3σ

### 2.4 Interquartile Range (IQR)

```ascii
Data: 2, 4, 4, 4, 5, 5, 7, 9

Quartile Calculation:

Q1 (25th percentile) = 4
Q2 (Median) = 4.5
Q3 (75th percentile) = 5.75

IQR = Q3 - Q1 = 5.75 - 4 = 1.75

Box Plot:
    Q1    Q2    Q3
     ↓     ↓     ↓
2    |-----+-----|    9
     └─ IQR = 1.75 ─┘
```

#### Key Points:
- Definition: Difference between 3rd and 1st quartiles
- Uses:
  * Identifying outliers
  * Creating box plots
  * Robust measure of spread
- Outlier Detection:
  * Lower fence: Q1 - 1.5×IQR
  * Upper fence: Q3 + 1.5×IQR

## 3. Distribution Shapes

### 3.1 Symmetric Distribution

```ascii
    Normal Distribution
         ___/\___
     ___/      \___
    /              \
   /                \
--/------------------\--
   |    |    |    |
  -2σ  -1σ   μ   +1σ  +2σ
```

### 3.2 Skewed Distributions

```ascii
Right (Positive) Skew:
    ___/\
   /     \___
--/----------\___
Mean > Median > Mode

Left (Negative) Skew:
      /\___
   ___/    \
___/----------\--
Mode > Median > Mean
```

### 3.3 Kurtosis

```ascii
Platykurtic (Low, Flat):
    __/\__
   /      \
--/--------\--

Mesokurtic (Normal):
     /\
   _/  \_
--/------\--

Leptokurtic (High, Peaked):
      /\
    _/  \_
---/------\---
```

## 4. Practical Applications

### 4.1 Five-Number Summary

```ascii
Components:
1. Minimum
2. Q1 (25th percentile)
3. Median (50th percentile)
4. Q3 (75th percentile)
5. Maximum

Box Plot Representation:
    Q1    Median   Q3
     ↓      ↓      ↓
Min  |------+------|  Max
 ↓   |      |      |   ↓
 2   4    4.5     5.75  9
```

### 4.2 Z-Score Standardization

```ascii
Formula: Z = (x - μ) ÷ σ

Standardized Scale:
              0
              ↓
-3    -2    -1     1     2     3
|-----|-----|-----|-----|-----|-----|
      68% of data
|----------------|
      95% of data
|-------------------------|
      99.7% of data
|----------------------------------|