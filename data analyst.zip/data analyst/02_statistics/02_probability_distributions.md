# Probability and Statistical Distributions

## 1. Probability Fundamentals

### 1.1 Sample Space and Events

```ascii
Sample Space (S)
┌─────────────────────────────┐
│           ┌──────┐          │
│    Event A│      │Event B   │
│           │  A∩B │          │
│           │      │          │
│           └──────┘          │
└─────────────────────────────┘
```

#### Key Concepts:
- Sample Space (S): Set of all possible outcomes
- Event: Subset of sample space
- Intersection (A∩B): Outcomes common to both events
- Union (A∪B): Outcomes in either event

### 1.2 Probability Rules

```ascii
Addition Rule:
P(A∪B) = P(A) + P(B) - P(A∩B)

Multiplication Rule:
P(A∩B) = P(A) × P(B|A)

Visual Representation:
     P(A)    P(B)
  ┌───────┬───────┐
  │       │       │
  │   A   │   B   │
  │       │       │
  └───────┴───────┘
    P(A∩B)
```

## 2. Discrete Probability Distributions

### 2.1 Binomial Distribution

```ascii
Probability Mass Function:
P(X = k) = C(n,k) × p^k × (1-p)^(n-k)

Example (n=5, p=0.5):
   Probability
   ^
0.4-│
0.3-│    ■
0.2-│  ■ │ ■
0.1-│■ │ │ │ ■
   0┴─┴─┴─┴─┴─┴─>
    0 1 2 3 4 5  k
```

#### Properties:
- Mean (μ) = np
- Variance (σ²) = np(1-p)
- Used for success/failure scenarios
- Fixed number of trials (n)

### 2.2 Poisson Distribution

```ascii
Probability Mass Function:
P(X = k) = (λ^k × e^-λ) / k!

Example (λ=3):
   Probability
   ^
0.2-│
   -│    ■
0.1-│  ■ │ ■
   -│■ │ │ │ ■
   0┴─┴─┴─┴─┴─┴─>
    0 1 2 3 4 5  k
```

#### Properties:
- Mean (μ) = λ
- Variance (σ²) = λ
- Models rare events
- Events occur independently

## 3. Continuous Probability Distributions

### 3.1 Normal Distribution

```ascii
Probability Density Function:
         1              -(x-μ)²
f(x) = ───── × exp(────────────)
       σ√2π             2σ²

      Standard Normal Distribution
              │
              ▲
             ╱ ╲
           ╱     ╲
         ╱         ╲
       ╱             ╲
     ╱                 ╲
────┴────┴────┴────┴────┴────
   -2σ  -1σ   μ   +1σ  +2σ
```

#### Properties:
- Symmetric about mean
- Bell-shaped curve
- 68-95-99.7 rule
- Defined by μ and σ

### 3.2 Student's t-Distribution

```ascii
     Normal vs t-Distribution
              │
              ▲  Normal
             ╱ ╲
           ╱     ╲
         ╱    t    ╲
       ╱             ╲
     ╱                 ╲
────┴────┴────┴────┴────┴────
   -2    -1    0    1    2
```

#### Properties:
- Similar to normal distribution
- Heavier tails
- Used for small samples
- Approaches normal as df increases

### 3.3 Chi-Square Distribution

```ascii
Probability Density Function:
   ^
   │
   │    df=2
   │     ╱╲
   │    ╱  ╲   df=4
   │   ╱    ╲  ╱╲
   │  ╱      ╲╱  ╲
   │ ╱            ╲
   │╱              ╲
   └───────────────────>
   0     5     10    15
```

#### Properties:
- Right-skewed
- Non-negative values
- Shape depends on df
- Used for variance analysis

## 4. Sampling Distributions

### 4.1 Central Limit Theorem

```ascii
Population → Sample Means → Normal Distribution

 Original        Sampling
Distribution    Distribution
    ╱╲             ╱╲
   ╱  ╲     →     ╱  ╲
  ╱    ╲         ╱    ╲
 ╱      ╲       ╱      ╲
        n samples
```

#### Key Points:
- Sample means follow normal distribution
- True for any population distribution
- Requires large enough sample size (n≥30)

### 4.2 Standard Error

```ascii
SE = σ/√n

Effect of Sample Size:
n=10   ╱╲
n=30  ╱──╲    Narrower
n=100╱────╲   Distribution
     μ
```

## 5. Probability Applications

### 5.1 Confidence Intervals

```ascii
        95% Confidence Interval
              │
              ▲
             ╱ ╲
           ╱     ╲
         ╱         ╲
       ╱             ╲
     ╱                 ╲
────┴────┴────┴────┴────┴────
    LCL   -1σ   μ   +1σ   UCL

LCL = Lower Confidence Limit
UCL = Upper Confidence Limit
```

### 5.2 Hypothesis Testing

```ascii
Null Hypothesis (H₀) Region
       │
       ▲
      ╱ ╲
     ╱   ╲
    ╱     ╲
   ╱       ╲
  ╱         ╲
─┴───┴───┴───┴───┴─
  Rejection  Rejection
   Region     Region
   (α/2)      (α/2)
```

#### Critical Components:
- Null hypothesis (H₀)
- Alternative hypothesis (H₁)
- Significance level (α)
- Test statistic
- p-value

## 6. Practical Examples

### 6.1 Quality Control

```ascii
Control Chart
     UCL
      ┌──────────────────
      │    *  *
 Mean ├──*─────*──*───*──
      │       *    *
      │
     LCL
      └──────────────────
        Time →
```

### 6.2 Risk Analysis

```ascii
Risk Matrix
 Impact │
High    │ M H H
Medium  │ L M H
Low     │ L L M
        └─────────
         L M H
      Probability
```

Remember:
- Always check assumptions
- Consider sample size
- Use appropriate tests
- Validate results